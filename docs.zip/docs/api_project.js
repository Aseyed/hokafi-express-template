define({
  "name": "time-sheet",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-11-30T20:09:14.032Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
